const CONFIG_URL = 'link_github';
async function getSecurityStatus() {
  try {
    const res = await fetch(CONFIG_URL + `?t=${Date.now()}`);
    const config = await res.json();
    return config.active === true;
  } catch (err) {
    console.error('❌ Gagal ambil config:', err.message);
    return false;
  }
}

async function jalankanAplikasi() {
  const aktif = await getSecurityStatus();
  const red = '\x1b[31m';
  const reset = '\x1b[0m';
  if (!aktif) {
    console.error(`${red}Error: Cannot find module 'fs'
Require stack:
- internal/modules/cjs/loader.js
- internal/modules/cjs/helpers.js
- internal/main/run_main_module.js${reset}`);
    process.exit(1);
  } else {
  }
}
jalankanAplikasi();